﻿using System;
using System.Collections.Generic;
using System.Text;

namespace bd.swrm.entidades.Enumeradores
{
    public enum Aplicacion
    {
        SwRm
    }
}
